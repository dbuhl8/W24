



HW4 Instructions

All of the for each part of the assignment are in their own separate folders.

In the tar file, you should find 5 folders. 

1. hello

2. sendrec

3. ping

4. ring

5. pi

In each folder, you will find an .f90 file, an MPI executable, a PBS .cmd file, and an output file titled "job_name"O

In each .cmd file, you will find the commands needed to compile and execute each .f90/mpi file/executable. 

A sample output of each is placed in the output file of each folder. 





