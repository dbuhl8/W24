

Hey Nate, 

This is your guide to my demented method of running fortran scripts. 
In order to produce executables you need to navigate into the fortran directory and type "make all" into the terminal. This will produce 4 .e files in that director. Each corresponding to a problem in final form (some exercises ask you to modify versions of the code from other exercises). 

A log of all code outputs in order with labels is in the exerciselog.txt file. 

Finally a pdf of my typed latex report is in the main directory, but the tex source is in the report directory. 

Let me know if you have any questions. 
-Dante

